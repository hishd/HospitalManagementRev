#include<iostream>
#include<cstdlib>
#include<stdlib.h>
#include<cstring>
#include<conio.h>
#include<unistd.h>
#include<fstream>
#include<sstream>
#include<iomanip>
#include<windows.h>

using namespace std;

class receptionist;
class wardroom;
class bill;
class medicalbill;
class wardbill;
class pharmacist;

void about();
void delay();
void loginmenu();
void doclogselect();

void gotoxy(int x, int y)
{
    COORD c = { x, y };  
    SetConsoleCursorPosition(  GetStdHandle(STD_OUTPUT_HANDLE) , c);
}

//classes
/////////////////////////////////////////////////// CLASS PATIENT ///////////////////////////////////////////////
class patient
{
		string p_id;
		string name;
		string sex;
		string age;
		string address;
		string bloodgroup;
		
		public:
			~patient(){}
			void getdata();
			void getbkdata();
			friend receptionist;
			friend wardroom;
			//void registerpatient();
};

void patient::getdata()	////////// Get Patient data for medical patients
{
	int id;
	sex = "a";
	bloodgroup="x";
	ifstream read;
	ofstream write;
	ofstream master;
	
	read.open("patient/patientid");
	read>>id;
	read.close();
	id++;

	ostringstream convert;
	convert<<id;
	p_id = convert.str();
	printf("\033c");
	
	cout<<"Patient ID : "<<p_id;
	cout<<"\n\nEnter Name : ";
	cin.ignore();
	getline(cin,name);
	
	while(sex!="m"&&sex!="M"&&sex!="f"&&sex!="F")
	{
		cout<<"\nEnter Sex (Use 'M' or 'F') : ";
		cin>>sex;
	}
	
	cout<<"\n\nEnter Age : "; cin>>age;
	
	cout<<"\n\nEnter Address : ";
	cin.ignore();
	getline(cin,address);
	
	while(bloodgroup!="A"&&bloodgroup!="B"&&bloodgroup!="O"&&bloodgroup!="AB")
	{
		cout<<"\nEnter BloodGroup 'A' , 'B' , 'O' , 'AB': ";
		cin>>bloodgroup;
	}
	write.open("patient/patientid");
	write<<id;
	write.close();
	
	master.open("patient/masterfile",ios::app);
	master<<"\nPID = "<<p_id<<" Name = "<<name<<"\tSEX = "<<sex<<"\tAge = "<<age<<"\tAddress = "<<address<<"\tBloodgroup = "<<bloodgroup<<endl;
	master.close();
}

void patient::getbkdata()	///////////////////Get patient data for upcoming patients
{

	sex = "a";
	bloodgroup="x";
	
	printf("\033c");
	
	cout<<"\n\nEnter Name : ";
	cin.ignore();
	getline(cin,name);
	
	while(sex!="m"&&sex!="M"&&sex!="f"&&sex!="F")
	{
		cout<<"\nEnter Sex (Use 'M' or 'F') : ";
		cin>>sex;
	}
	
	cout<<"\n\nEnter Age : "; 
	cin>>age;
	
	cout<<"\n\nEnter Address : ";
	cin.ignore();
	getline(cin,address);
	
	while(bloodgroup!="A"&&bloodgroup!="B"&&bloodgroup!="O"&&bloodgroup!="AB")
	{
		cout<<"\nEnter BloodGroup 'A' , 'B' , 'O' , 'AB': ";
		cin>>bloodgroup;
	}

}

//////////////////////////////////////////////////////////// CLASS REPORT ///////////////////////////////////////////////////

class report
{
	protected:
		string patientid;
		int repno;
		string medicine;
		string test;
		virtual void createreport()	{}
	public:
		~report(){}
};

class medicalreport:report	////////////////////// Class Medical Report //////////////////////////
{
	public:
		~medicalreport(){}
		void createreport();
};

void medicalreport::createreport()	///////////// Creating report for medical patients
{
	printf("\033c");
	ifstream rfile;
	ofstream wfile;
	ofstream report;
	ofstream master;
	
	rfile.open("report/reportid");
	rfile>>repno;
	rfile.close();
	
	repno++;
	cout<<"Report ID : "<<repno;
	cout<<"\nEnter Patient ID : ";
	cin>>patientid;
	cout<<"\n\nEnter Medicine (use _ for space): ";
	cin.ignore();
	getline(cin,medicine);
	cout<<"\nEnter Tests done (use _ for space if not available please enter N/A) : ";
	//cin.ignore();
	getline(cin,test);
	
	wfile.open("report/reportid");
	wfile<<repno;
	wfile.close();
	
	report.open("report/medical/report",ios::app);
	report<<repno<<"\t"<<patientid<<"\t"<<medicine<<"\t"<<test<<endl;
	report.close();
	
	master.open("report/medical/masterreport",ios::app);
	master<<repno<<"\t"<<patientid<<"\t"<<medicine<<"\t"<<test<<endl;
	master.close();
}

class wardreport:report
{
	public:
		~wardreport(){}
		void createreport();
};

void wardreport::createreport()	///////////// Creating report for ward patients
{
	printf("\033c");
	ifstream rfile;
	ofstream wfile;
	ofstream report;
	ofstream master;
	string roomno;
	
	rfile.open("report/reportid");
	rfile>>repno;
	rfile.close();
	
	repno++;
	cout<<"Report ID : "<<repno;
	cout<<"\nEnter Patient ID : ";
	cin>>patientid;
	cout<<"\n\nEnter Roomno : ";
	cin.ignore();
	getline(cin,roomno);
	cout<<"\n\nEnter Medicine (use _ for space): ";
	//cin.ignore();
	getline(cin,medicine);
	cout<<"\nEnter Tests done (use _ for space if not available please enter N/A) : ";
	//cin.ignore();
	getline(cin,test);
	
	wfile.open("report/reportid");
	wfile<<repno;
	wfile.close();
	
	report.open("report/ward/report",ios::app);
	report<<repno<<"\t"<<patientid<<"\t"<<roomno<<"\t"<<medicine<<"\t"<<test<<endl;
	report.close();
	
	master.open("report/ward/masterreport",ios::app);
	master<<repno<<"\t"<<patientid<<"\t"<<roomno<<"\t"<<medicine<<"\t"<<test<<endl;
	master.close();
}

/////////////////////////////////////////////// CLASS DOCTOR //////////////////////////////////////////////////////////////////

class doctor
{
	string username;
	string password;
	
	protected:
		string docname;

	public:
		~doctor(){}
		char docmenu();
		
		doctor()
		{
			username = "doctor";
			password = "doctor";
		}
		string getuname()
		{
			return username;
		}
		
		string getpwrd()
		{
			return password;
		}
		
		virtual void registerdoc() {};
		virtual void viewpatients()	{};
		virtual void finalizeday()	{};
		virtual void create_report() {};
};

char doctor::docmenu()
{
	ifstream doc;
	string audio;
	string cardio;
	string neuro;
	string dermato;
	char ch;
	//////////////////////////////
	doc.open("doctor/audiologist/audiologist");
	
	if(doc==NULL)
	{
		audio = "N/A";
	}
	else
	{
		getline(doc,audio);
	}
	doc.close();
	////////////////////////////
	doc.open("doctor/cardiologist/cardiologist");
	
	if(doc==NULL)
	{
		cardio = "N/A";
	}
	else
	{
		getline(doc,cardio);
	}
	doc.close();
	////////////////////////////
	doc.open("doctor/dermatologist/dermatologist");
	
	if(doc==NULL)
	{
		dermato = "N/A";
	}
	else
	{
		getline(doc,dermato);
	}
	doc.close();
	////////////////////////////
	doc.open("doctor/neurologist/neurologist");
	
	if(doc==NULL)
	{
		neuro = "N/A";
	}
	else
	{
		getline(doc,neuro);
	}
	doc.close();
	
	printf("\033c");
	cout<<"========== Welcome Doctor ==========\n\n";
	cout<<"1.Audiologist = Dr. "<<audio;
	cout<<"\n2.Cardiologist = Dr. "<<cardio;
	cout<<"\n3.Neurologist = Dr. "<<neuro;
	cout<<"\n4.Dermatologist = Dr. "<<dermato;
	cout<<"\n5.Login Menu";
	cout<<"\n6.Exit";
	
	cout<<"\n\nEnter your choice : ";
	cin>>ch;
	
	return ch;
}

class audiologist:doctor
{
	public:
		
		~audiologist(){}
		
		void registerdoc()
		{
			ofstream file2;
			file2.open("doctor/audiologist/audiologist");
			cout<<"Enter Doctor Name : ";
			cin>>docname;
			file2<<docname;
			file2.close();	
		}	
		void viewpatients()	
		{
			ifstream read;
			char c;
			read.open("doctor/audiologist/patients");
			if(read==NULL)
			{
				cout<<"\nNo Patients"<<endl;
				system("PAUSE");
			}
			else
			{
			
				while(read.get(c))
				cout<<c;
				read.close();
				cout<<"\n\n";
				system("PAUSE");
			}
		}
		
		void finalizeday()	
		{
			ofstream clear;
			ofstream reset;
			clear.open("doctor/audiologist/patients");
			clear.close();
			reset.open("doctor/audiologist/pcount");
			reset<<0;
			reset.close();
			remove("doctor/audiologist/patients");
			cout<<"\n\nDay was finalized successfully\n\n";
			system("pause");
		}	
		
		void create_report() 
		{
			medicalreport m;
			m.createreport();
		}
};

class cardiologist:doctor
{
	public:
		~cardiologist(){}
		void registerdoc()
		{
			ofstream file2;
			file2.open("doctor/cardiologist/cardiologist");
			cout<<"Enter Doctor Name : ";
			cin>>docname;
			file2<<docname;
			file2.close();	
		}
		
		void viewpatients()	
		{
			ifstream read;
			char c;
			read.open("doctor/cardiologist/patients");
			if(read==NULL)
			{
				cout<<"\nNo Patients"<<endl;
				system("PAUSE");
			}
			else
			{
			
				while(read.get(c))
				cout<<c;
				read.close();
				cout<<"\n\n";
				system("PAUSE");
			}
		}
		
		void finalizeday()	
		{
			ofstream clear;
			ofstream reset;
			clear.open("doctor/cardiologist/patients");
			clear.close();
			reset.open("doctor/cardiologist/pcount");
			reset<<0;
			reset.close();
			remove("doctor/cardiologist/patients");
			cout<<"\n\nDay was finalized successfully\n\n";
			system("pause");
		}
		
		void create_report() 
		{
			medicalreport m;
			m.createreport();
		}
};

class dermatologist:doctor
{
	public:
		
		~dermatologist(){}
		
		void registerdoc()
		{
			ofstream file2;
			file2.open("doctor/dermatologist/dermatologist");
			cout<<"Enter Doctor Name : ";
			cin>>docname;
			file2<<docname;
			file2.close();	
		}
		
		void viewpatients()	
		{
			ifstream read;
			char c;
			read.open("doctor/dermatologist/patients");
			if(read==NULL)
			{
				cout<<"\nNo Patients"<<endl;
				system("PAUSE");
			}
			else
			{
			
				while(read.get(c))
				cout<<c;
				read.close();
				cout<<"\n\n";
				system("PAUSE");
			}
		}
		
		void finalizeday()	
		{
			ofstream clear;
			ofstream reset;
			clear.open("doctor/dermatologist/patients");
			clear.close();
			reset.open("doctor/dermatologist/pcount");
			reset<<0;
			reset.close();
			remove("doctor/dermatologist/patients");
			cout<<"\n\nDay was finalized successfully\n\n";
			system("pause");
		}
		
		void create_report() 
		{
			medicalreport m;
			m.createreport();
		}
};

class neurologist:doctor
{
	public:
		~neurologist(){}
		void registerdoc()
		{
			ofstream file2;
			file2.open("doctor/neurologist/neurologist");
			cout<<"Enter Doctor Name : ";
			cin>>docname;
			file2<<docname;
			file2.close();	
		}
		
		void viewpatients()	
		{
			ifstream read;
			char c;
			read.open("doctor/neurologist/patients");
			if(read==NULL)
			{
				cout<<"\nNo Patients"<<endl;
				system("PAUSE");
			}
			else
			{
			
				while(read.get(c))
				cout<<c;
				read.close();
				cout<<"\n\n";
				system("PAUSE");
			}
		}
		
		void finalizeday()	
		{
			ofstream clear;
			ofstream reset;
			clear.open("doctor/neurologist/patients");
			clear.close();
			reset.open("doctor/neurologist/pcount");
			reset<<0;
			reset.close();
			remove("doctor/neurologist/patients");
			cout<<"\n\nDay was finalized successfully\n\n";
			system("pause");
		}
		
		void create_report() 
		{
			medicalreport m;
			m.createreport();
		}
};

/*
class entspecailist:doctor
{

};

class psychiatrist:doctor
{

};

*/

void doclogselect()
{
	doctor d;
	A:
	char ch = d.docmenu();
	
	switch(ch)
	{
		case '1':
			{
				A1:
				printf("\033c");
				audiologist a;
				char inc;
				cout<<"\n========== Welcome Doctor ==========\n\n";
				cout<<"1.View Patients";
				cout<<"\n2.Create a Report";
				cout<<"\n3.Finalize the day";
				cout<<"\n4.Logout";
				cout<<"\n5.Exit";
				
				cout<<"\n\nEnter your choice : ";
				//cin.ignore();
				//cin>>inc;
				inc = getch();
				
				switch(inc)
				{
					case '1':
						{
							a.viewpatients();
							goto A1;
						}	break;
						
					case '2':
						{
							a.create_report();
							goto A1;
						}	break;
						
					case '3':
						{
							a.finalizeday();
							goto A1;
						}	break;
						
					case '4': loginmenu();	break;
					
					case '5': exit(2);	break;
					
					default:
						cout<<"\n\nInvalid Choice";
						goto A1;
						break;
				}
				
			}	break;
			
		case '2':
			{
				cardiologist c;
				B1:
				printf("\033c");
				char inc;
				cout<<"\n========== Welcome Doctor ==========\n\n";
				cout<<"1.View Patients";
				cout<<"\n2.Create a Report";
				cout<<"\n3.Finalize the day";
				cout<<"\n4.Logout";
				cout<<"\n5.Exit";
				
				cout<<"\n\nEnter your choice : ";
				//cin.ignore();
				//cin>>inc;
				inc = getch();
				
				
				switch(inc)
				{
					case '1':
						{
							c.viewpatients();
							goto B1;
						}	break;
						
					case '2':
						{
							c.create_report();
							goto B1;
						}	break;
						
					case '3':
						{
							c.finalizeday();
							goto B1;
						}	break;
						
					case '4': loginmenu();	break;
					
					case '5': exit(2);	break;
					
					default:
						cout<<"\n\nInvalid Choice";
						goto B1;
						break;
				}
				
			}	break;
			
		case '3':
			{
				neurologist n;
				C1:
				printf("\033c");
				char inc;
				cout<<"\n========== Welcome Doctor ==========\n\n";
				cout<<"1.View Patients";
				cout<<"\n2.Create a Report";
				cout<<"\n3.Finalize the day";
				cout<<"\n4.Logout";
				cout<<"\n5.Exit";
				
				cout<<"\n\nEnter your choice : ";
				//cin.ignore();
				//cin>>inc;
				inc = getch();
				
				switch(inc)
				{
					case '1':
						{
							n.viewpatients();
							goto C1;
						}	break;
						
					case '2':
						{
							n.create_report();
							goto C1;
						}	break;
						
					case '3':
						{
							n.finalizeday();
							goto C1;
						}	break;
						
					case '4': loginmenu();	break;
					
					case '5': exit(2);	break;
					
					default:
						cout<<"\n\nInvalid Choice";
						goto C1;
						break;
				}
				
			}	break;
			
		case '4':
			{
				dermatologist d;
				D1:
				printf("\033c");
				char inc;
				cout<<"\n========== Welcome Doctor ==========\n\n";
				cout<<"1.View Patients";
				cout<<"\n2.Create a Report";
				cout<<"\n3.Finalize the day";
				cout<<"\n4.Logout";
				cout<<"\n5.Exit";
				
				cout<<"\n\nEnter your choice : ";
				//cin.ignore();
				//cin>>inc;
				inc = getch();
				
				switch(inc)
				{
					case '1':
						{
							d.viewpatients();
							goto D1;
						}	break;
						
					case '2':
						{
							d.create_report();
							goto D1;
						}	break;
						
					case '3':
						{
							d.finalizeday();
							goto D1;
						}	break;
						
					case '4': loginmenu();	break;
					
					case '5': exit(2);	break;
					
					default:
						cout<<"\n\nInvalid Choice";
						goto D1;
						break;
				}
				
			}	break;
		
		case '5':
			{
				
			}	break;
		case '6':
			exit(2);	break;
		
		default:
			{
				cout<<"\n\nInvalid Choice\n\n";
				system("pause");
				goto A;
			}
	}
}

class admin
{
	
		string username;
		string password;
		
	public:
		
		void adminmenu();
		void editpharmacy();
		void createreceptionist();
		void createcashier();
		void createdoctor();
		void createwarden();
		void viewlogindetails();
		void viewcashdetails();
		void handlereport();
		void handlepatient();
		void handlebill();
		
		string getuname()
		{
			return username;
		}
		string getpwrd()
		{
			return password;
		}
		
		admin()
		{
			username = "admin";
			password = "admin";
		}
		
		~admin(){}
};

void admin::adminmenu()
{
	char ch;

	 while(1)
	 	{
	 		printf("\033c");
	 		//printf("\033c"); //linux
	 		cout<<"\n\n\t\t***||WELCOME||***";
	        cout<<"\n\nYou have logged in successfully.";
	        cout<<"\n\n========== ADMIN MENU ==========\t\t\t\t\t\t\t      ";
	        cout<<"\na.Register Receptionist";
	        cout<<"\nb.Register Cashier";
	        cout<<"\nc.Register Doctor";
	        cout<<"\nd.Register Ward in Charge";
	        cout<<"\ne.Edit Pharmacy Access Details";
	        cout<<"\nf.View Login details";
	        cout<<"\ng.View total Settled amount";
	        cout<<"\nh.Handle Reports";
	        cout<<"\ni.Handle Patients";
	        cout<<"\nj.Handle Bills";
	        cout<<"\nk.Login menu";
	        cout<<"\nl.Exit";
	 		cout<<"\n\nEnter your choice (use lowercase letters) - ";
	 		//cin.ignore();
	 		ch = getch();

				switch(ch)
				{
					case 'a': createreceptionist(); break;
					case 'b': createcashier(); break;
					case 'c': createdoctor(); break;
					case 'd': createwarden(); break;
					case 'e': editpharmacy(); break;
					case 'f': viewlogindetails(); break;
					case 'g': viewcashdetails(); break;
					case 'h': handlereport();	break;
					case 'i': handlepatient();	break;
					case 'j': handlebill();	break;
					case 'k': loginmenu(); break;
					case 'l': exit(0); break;
					default: printf("invalid choice");

				}
		}
}

void admin::editpharmacy()
{
	string un;
	string pw;
	ofstream file;
	
	printf("\033c");
	file.open("pharmacist/phar");
	cout<<"\nEnter new username : ";
	cin>>un;
	cout<<"\nEnter new password : ";
	cin>>pw;
	file<<un<<endl;
	file<<pw;
	file.close();
	cout<<"\n\nPharmacist login details updated successfully \n\n";
	system("pause");
}

void admin::createreceptionist()
{
	string uname,password;
	printf("\033c");
	cout<<"Username : "; cin>>uname;
	cout<<"\nPassword : "; cin>>password;
	ofstream file;

	//file.open(uname.c_str());
	file.open("receptionist/recep");
	file<<uname<<endl<<password;
	file.close();
}

void admin::createcashier()
{
	string uname,password;
	printf("\033c");
	cout<<"Username : "; cin>>uname;
	cout<<"\nPassword : "; cin>>password;
	ofstream file;

	//file.open(uname.c_str());
	file.open("cashier/cash");
	file<<uname<<endl<<password;
	file.close();
}

void admin::createdoctor()
{
	char ch;
	ifstream file1;
	string docname;
	
	audiologist a;
	cardiologist c;
	neurologist n;
	dermatologist d;
	
	A:
	printf("\033c");
	cout<<"\n========== Registration Menu ==========\n"<<endl;
	cout<<"1.Audiologist"<<endl;
	cout<<"2.Cardiologist"<<endl;
	cout<<"3.Dermatologist"<<endl;
	cout<<"4.Neurologist"<<endl;
	cout<<"5.Back"<<endl;
	cout<<"Enter The Catogory of The Doctor : "; 
	//cin.ignore();	
	//cin>>ch;
	ch = getch();
	
		switch(ch)
		{
		
			case '1':
				{	
					file1.open("doctor/audiologist/audiologist");
					if(file1!=NULL)
					{
						string name;
						file1>>name;
						D:
						cout<<"\n\nan Audiologist is already in the system the name is "<<name<<" if you wish to replace the doctor press 1  else press 2 : ";
						cin>>ch;
						if(ch=='1')
						{
							a.registerdoc();	
						}
						else if(ch=='2')
						{
							cout<<"\nRecord kept as it is"<<endl;
							system("pause");	
						}
							
						else
						{
							cout<<"Invalid Choice \n";
							goto D;
						}
					}
					
					else
					{
						a.registerdoc();
					}
					
				}	break;
				
			case '2':
				{
					file1.open("doctor/cardiologist/cardiologist");
					if(file1!=NULL)
					{
						string name;
						file1>>name;
						E:
						cout<<"\n\nan Cardiologist is already in the system the name is "<<name<<" if you wish to replace the doctor press 1 else press 2 : ";
						cin>>ch;
						if(ch=='1')
						{
							c.registerdoc();
						}
						else if(ch=='2')
						{
						cout<<"\nRecord kept as it is"<<endl;
						system("pause");	
						}
						else
						{
							cout<<"Invalid Choice \n";
							goto E;
						}
					}
					
					else
					{
						c.registerdoc();
					}
					
				}	break;
				
			case '3':
				{
					file1.open("doctor/dermatologist/dermatologist");
					if(file1!=NULL)
					{
						string name;
						getline(file1,name);
						F:
						cout<<"\n\nan Dermatologist is already in the system the name is "<<name<<" if you wish to replace the doctor press 1 else press 2: ";
						cin>>ch;
						if(ch=='1')
						{
							d.registerdoc();
						}
						else if(ch=='2')
						{
							cout<<"\nRecord kept as it is"<<endl;
							system("pause");	
						}
						else
						{
							cout<<"Invalid Choice \n";
							goto F;
						}
					}
					
					else
					{
						d.registerdoc();
					}
					
				}	break;
				
			case '4':
				{
					file1.open("doctor/neurologist/neurologist");
					if(file1!=NULL)
					{
						string name;
						getline(file1,name);
						G:
						cout<<"\n\nan Neurologist is already in the system the name is "<<name<<" if you wish to replace the doctor press 1 else press 2: ";
						cin>>ch;
						if(ch=='1')
						{
							n.registerdoc();
						}
						else if(ch=='2')
						{
							cout<<"\nRecord kept as it is"<<endl;
							system("pause");	
						}
						else
						{
							cout<<"Invalid Choice \n";
							goto G;
						}
					}
					
					else
					{
						n.registerdoc();
					}
					
				}	break;
				
			case '5': adminmenu(); break;
			
			default:
				{
					cout<<"Invalid Choice";
					goto A;
				}
		}
	file1.close();
	
}

void admin::createwarden()
{
	string uname,password;
	printf("\033c");
	cout<<"Username : "; cin>>uname;
	cout<<"\nPassword : "; cin>>password;
	ofstream file;

	//file.open(uname.c_str());
	file.open("warden/ward");
	file<<uname<<endl<<password;
	file.close();
}

void admin::viewlogindetails()
{
	ifstream read;
	char c;
	
	read.open("logs/userlog");
	
	if(read==NULL)
	{
		cout<<"\nNo Login Details"<<endl;
		system("PAUSE");
	}
	else
	{
	
		while(read.get(c))
		cout<<c;
		read.close();
		cout<<"\n\n";
		system("PAUSE");
	}
}

void admin::viewcashdetails()
{
	ifstream med;
	ifstream ward;
	
	float mcount,wcount,mamount,wamount;
	
	med.open("bills/medsum");
	med>>mcount;
	med>>mamount;
	med.close();
	
	ward.open("bills/wardsum");
	ward>>wcount;
	ward>>wamount;
	ward.close();
	
	printf("\033c");
	cout<<"\nTotal Medical Patients : "<<mcount;
	cout<<"\nMedical patient Payments : Rs."<<mamount;
	cout<<"\n\nTotal Ward Patients : "<<wcount;
	cout<<"\nWard patient Payments : Rs."<<wamount;
	cout<<"\n\n";
	system("pause");
}

void admin::handlereport()
{
	int ch;
	char c;
	D:	
	printf("\033c");
	cout<<"1.View Master Report file";
	cout<<"\n2.Reset Report ID";
	cout<<"\n3.Back";
	
	cout<<"\n\nEnter your choice : ";
	cin>>ch;
	
	if(ch==1)
	{
		ifstream file;
		file.open("report/medical/masterreport");
		cout<<"\nMedical Master Report\n\n";
		while(file.get(c))
		cout<<c;
		file.close();
		cout<<"\n";
		
		file.open("report/ward/masterreport");
		cout<<"\nWard Master Report\n\n";
		while(file.get(c))
		cout<<c;
		file.close();
		cout<<"\n";
		system("pause");
	}
	else if(ch==2)
	{
		ofstream file;
		file.open("report/reportid");
		file<<0;
		file.close();
	}
	else if(ch==3)
	{
		admin a;
		a.adminmenu();
	}
	else
	{
		cout<<"\n\nInvalid Choice\n\n";
		system("pause");
		goto D;
	}
}

void admin::handlepatient()
{
	int ch;
	char c;
	D:	
	printf("\033c");
	cout<<"1.View Master Patient file";
	cout<<"\n2.Reset Patient ID";
	cout<<"\n3.Back";
	
	cout<<"\n\nEnter your choice : ";
	cin>>ch;
	
	if(ch==1)
	{
		ifstream file;
		file.open("patient/masterfile");
		cout<<"\nPatient Master File\n\n";
		while(file.get(c))
		cout<<c;
		file.close();
		cout<<"\n";
		system("pause");
	}
	else if(ch==2)
	{
		ofstream file;
		file.open("patient/patientid");
		file<<0;
		file.close();
	}
	else if(ch==3)
	{
		admin a;
		a.adminmenu();
	}
	else
	{
		cout<<"\n\nInvalid Choice\n\n";
		system("pause");
		goto D;
	}
}

void admin::handlebill()
{
	int ch;
	char c;
	D:	
	printf("\033c");
	cout<<"1.View Master Bill file";
	cout<<"\n2.Reset Bill No";
	cout<<"\n3.Back";
	
	cout<<"\n\nEnter your choice : ";
	cin>>ch;
	
	if(ch==1)
	{
		ifstream file;
		file.open("bills/master");
		cout<<"\nBill Master File\n\n";
		while(file.get(c))
		cout<<c;
		file.close();
		cout<<"\n";
		system("pause");
	}
	else if(ch==2)
	{
		ofstream file;
		file.open("bills/bno");
		file<<0;
		file.close();
	}
	else if(ch==3)
	{
		admin a;
		a.adminmenu();
	}
	else
	{
		cout<<"\n\nInvalid Choice\n\n";
		system("pause");
		goto D;
	}
}

class receptionist
{
	string uname;
	char password[15];
	string un;
	string pw;

	public:
		~receptionist(){}
		bool receplogin();
		void receptionistmenu();
		void viewdoclist();
		void registerpatient();
		void viewpatient();
		void bookadates();
		void viewbookeddates();
};

bool receptionist::receplogin()
{
	char c=' ';
	int n=1,i=0,a,b;
	string un,pw;
	ofstream flog;

	cout<<"\nEnter USER ID and PASSWORD below (You have only three chances to enter)";
	system("PAUSE");

	while(n<=3)
	{
		printf("\033c");
  		cout<<"\nUSER ID: ";
  		cin>>uname;
  		cout<<"\nPASSWORD: ";
  		while (i<=10)
		  {
		    password[i]=getch();
		    c=password[i];
		    if(c==13) break;
		    else printf("*");
		    i++;
		  }

	      password[i]='\0';
	      i=0;
	      printf("\033c");

	    //string su =string(uname);
	    string sp =string(password);

	    ifstream file("receptionist/recep");
	    if(file==NULL)
	    {
	    	cout<<"Theres no Signup details of Receptionist Please Contact Administrator for Registration"<<endl;
	    	system("PAUSE");
	    	loginmenu();
		}
		getline(file,un);
		getline(file,pw);
		file.close();

	    //a=uname.compare();
  		//b=sp.compare();

  		if(uname==un && sp==pw)
  		{
  			flog.open("logs/userlog",ios::app);
  			flog<<"\nLogin ID : Receptionist\t\tTime : "<<__TIMESTAMP__;
  			flog.close();
  			return true;
		}
		else
		{

			cout<<"\nWrong PASSWORD and/or USER ID. Now you have "<<3-n<<" more chance/s.";
	        sleep(2);
	        printf("\033c");
		}
	    n++;
	}

	if(n==4)
   	{
   		printf("\nYou can't log in.");
		delay();
	}

}

void receptionist::receptionistmenu()
{
	char ch;
	
	while(1)
	{
		printf("\033c");
		cout<<"========== Receptionist Menu ==========";
		cout<<"\n1.View Doctors list";
		cout<<"\n2.Register Patient";
		cout<<"\n3.View register Patient";
		cout<<"\n4.Book an upcoming Date";
		cout<<"\n5.View upcoming Booked dates";
		cout<<"\n6.Login Menu";
		cout<<"\n7.Exit";
		
		cout<<"\n\nEnter your Choice : ";
		//cin.ignore();
		//cin>>ch;
		ch = getch();
		
		switch(ch)
			{
				case '1':
					{	
						viewdoclist();
					}	break;
					
				case '2':
					{
						registerpatient();
					}	break;
					
				case '3':
					{
						viewpatient();
					}	break;
				
				case '4':
					{
						bookadates();
					}	break;
					
				case '5':
					{
						viewbookeddates();	
					}	break;
				
				case '6':
					{
						loginmenu();
					}	break;
					
				case '7': exit(1); break;
				
				default: { cout<<"\nInvalid Choice"<<endl;
							system("PAUSE"); }
				
			}
		
	}
	
}

void receptionist::viewdoclist()
{
	ifstream doc;
	string audio;
	string cardio;
	string neuro;
	string dermato;
	//////////////////////////////
	doc.open("doctor/audiologist/audiologist");
	
	if(doc==NULL)
	{
		audio = "N/A";
	}
	else
	{
		getline(doc,audio);
	}
	doc.close();
	////////////////////////////
	doc.open("doctor/cardiologist/cardiologist");
	
	if(doc==NULL)
	{
		cardio = "N/A";
	}
	else
	{
		getline(doc,cardio);
	}
	doc.close();
	////////////////////////////
	doc.open("doctor/dermatologist/dermatologist");
	
	if(doc==NULL)
	{
		dermato = "N/A";
	}
	else
	{
		getline(doc,dermato);
	}
	doc.close();
	////////////////////////////
	doc.open("doctor/neurologist/neurologist");
	
	if(doc==NULL)
	{
		neuro = "N/A";
	}
	else
	{
		getline(doc,neuro);
	}
	doc.close();
	
	
	printf("\033c");
	
	cout<<"========== List of Doctors Available =========="<<endl;
	cout<<"1.Audiologist   : "<<audio<<endl;
	cout<<"2.Cardiologist  : "<<cardio<<endl;
	cout<<"3.Neurologist   : "<<neuro<<endl;
	cout<<"4.Dermatologist : "<<dermato<<endl;
	system("pause");
}

void receptionist::registerpatient()
{	
	ifstream doc;
	ifstream rcount;
	ofstream wcount;
	int pcount;
	char ch;
	
	ofstream faudio;
	ofstream fcardio;
	ofstream fneuro;
	ofstream fdermato;
	
	string audio;
	string cardio;
	string neuro;
	string dermato;
	
	patient p;
	
	//////////////////////////////
	doc.open("doctor/audiologist/audiologist");
	
	if(doc==NULL)
	{
		audio = "N/A";
	}
	else
	{
		getline(doc,audio);
	}
	doc.close();
	////////////////////////////
	doc.open("doctor/cardiologist/cardiologist");
	
	if(doc==NULL)
	{
		cardio = "N/A";
	}
	else
	{
		getline(doc,cardio);
	}
	doc.close();
	////////////////////////////
	doc.open("doctor/dermatologist/dermatologist");
	
	if(doc==NULL)
	{
		dermato = "N/A";
	}
	else
	{
		getline(doc,dermato);
	}
	doc.close();
	////////////////////////////
	doc.open("doctor/neurologist/neurologist");
	
	if(doc==NULL)
	{
		neuro = "N/A";
	}
	else
	{
		getline(doc,neuro);
	}
	doc.close();
	
	D:
	printf("\033c");
	cout<<"========== Select Doctor Category ==========";
	cout<<"\n\n1.Audiologist : Dr."<<audio;
	cout<<"\n2.Cardiologist : Dr."<<cardio;
	cout<<"\n3.Neurologist : Dr."<<neuro;
	cout<<"\n4.Dermatologist : Dr."<<dermato;
	cout<<"\n5.Back";
	
	cout<<"\n\nEnter the catogory : "; 
	//cin.ignore();
	//cin>>ch;
	ch = getch();
	
	switch(ch)
	{
		case '1':
				{
					if(audio=="N/A")
					{
						printf("\033c");
						cout<<"Theres no Audiologist registered in the system please contact the system administrator";
						goto D;
								
					}
					else
					{
						rcount.open("doctor/audiologist/pcount");
						rcount>>pcount;
						rcount.close();
						wcount.open("doctor/audiologist/pcount");
						
						if(pcount>=10)
						{
							cout<<"\n\nMaximum no of 10 patients per has reached please book another date	";
							system("pause");
							goto D;
						}
						
						else
						{
							faudio.open("doctor/audiologist/patients",ios::app);
							p.getdata();
							faudio<<"\nPID = "<<p.p_id<<" Name = "<<p.name<<"\tSEX = "<<p.sex<<"\tAge = "<<p.age<<"\tAddress = "<<p.address<<"\tBloodgroup = "<<p.bloodgroup<<endl;
							faudio.close();
							wcount<<++pcount;
							wcount.close();
						}
						
						
								
					}
					
				}	break;
		case '2':
				{
					if(cardio=="N/A")
					{
						printf("\033c");
						cout<<"Theres no Cardiologist registered in the system please contact the system administrator";
						goto D;	
					}
					else
					{
						rcount.open("doctor/cardiologist/pcount");
						rcount>>pcount;
						rcount.close();
						wcount.open("doctor/cardiologist/pcount");
						
						if(pcount>=10)
						{
							cout<<"\n\nMaximum no of 10 patients per has reached please book another date	";
							system("pause");
							goto D;
						}
						
						else
						{
							fcardio.open("doctor/cardiologist/patients",ios::app);
							p.getdata();
							fcardio<<"\nPID = "<<p.p_id<<" Name = "<<p.name<<"\tSEX = "<<p.sex<<"\tAge = "<<p.age<<"\tAddress = "<<p.address<<"\tBloodgroup = "<<p.bloodgroup<<endl;
							fcardio.close();
							wcount<<++pcount;
							wcount.close();
						}
						
						
					}
					
				}	break;
		case '3':
				{
					if(neuro=="N/A")
					{
						printf("\033c");
						cout<<"Theres no Neurologist registered in the system please contact the system administrator";
						goto D;		
					}
					else
					{
						rcount.open("doctor/neurologist/pcount");
						rcount>>pcount;
						rcount.close();
						wcount.open("doctor/neurologist/pcount");
						
						if(pcount>=10)
						{
							cout<<"\n\nMaximum no of 10 patients per has reached please book another date	";
							system("pause");
							goto D;
						}
						
						else
						{
							fneuro.open("doctor/neurologist/patients",ios::app);
							p.getdata();
							fneuro<<"\nPID = "<<p.p_id<<" Name = "<<p.name<<"\tSEX = "<<p.sex<<"\tAge = "<<p.age<<"\tAddress = "<<p.address<<"\tBloodgroup = "<<p.bloodgroup<<endl;
							fneuro.close();	
							wcount<<++pcount;
							wcount.close();
						}
						
						
					}
					
				}	break;
		case '4':
				{
					if(dermato=="N/A")
					{
						printf("\033c");
						cout<<"Theres no Dermatologist registered in the system please contact the system administrator";
						goto D;		
					}
					else
					{
						rcount.open("doctor/dermatologist/pcount");
						rcount>>pcount;
						rcount.close();
						wcount.open("doctor/dermatologist/pcount");
						
						if(pcount>=10)
						{
							cout<<"\n\nMaximum no of 10 patients per has reached please book another date	";
							system("pause");
							goto D;
						}
						
						else
						{
							fdermato.open("doctor/dermatologist/patients",ios::app);
							p.getdata();
							fdermato<<"\nPID = "<<p.p_id<<" Name = "<<p.name<<"\tSEX = "<<p.sex<<"\tAge = "<<p.age<<"\tAddress = "<<p.address<<"\tBloodgroup = "<<p.bloodgroup<<endl;
							fdermato.close();
							wcount<<++pcount;
							wcount.close();
						}
						
							
					}
					
				}	break;
				
		case '5':	receptionistmenu();	break;
		
		default: cout<<"\n\nInvalid Choice";
	}
}

void receptionist::viewpatient()
{
	ifstream doc;
	ifstream read;

	string audio;
	string cardio;
	string neuro;
	string dermato;
	char ch;
	char c;
	
	//////////////////////////////
	doc.open("doctor/audiologist/audiologist");
	
	if(doc==NULL)
	{
		audio = "N/A";
	}
	else
	{
		getline(doc,audio);
	}
	doc.close();
	////////////////////////////
	doc.open("doctor/cardiologist/cardiologist");
	
	if(doc==NULL)
	{
		cardio = "N/A";
	}
	else
	{
		getline(doc,cardio);
	}
	doc.close();
	////////////////////////////
	doc.open("doctor/dermatologist/dermatologist");
	
	if(doc==NULL)
	{
		dermato = "N/A";
	}
	else
	{
		getline(doc,dermato);
	}
	doc.close();
	////////////////////////////
	doc.open("doctor/neurologist/neurologist");
	
	if(doc==NULL)
	{
		neuro = "N/A";
	}
	else
	{
		getline(doc,neuro);
	}
	doc.close();
	
	D:
	printf("\033c");
	cout<<"========== Select Doctor Category ==========";
	cout<<"\n\n1.Audiologist : Dr."<<audio;
	cout<<"\n2.Cardiologist : Dr."<<cardio;
	cout<<"\n3.Neurologist : Dr."<<neuro;
	cout<<"\n4.Dermatologist : Dr."<<dermato;
	cout<<"\n5.Back";
	
	cout<<"\n\nEnter the catogory : ";
	//cin.ignore();
	//cin>>ch;
	ch = getch();
	
	switch(ch)
	{
		case '1':
				{
					if(audio=="N/A")
					{
						printf("\033c");
						cout<<"Theres no Audiologist registered in the system please contact the system administrator";
						goto D;
								
					}
					else
					{
						read.open("doctor/audiologist/patients");
						if(read==NULL)
						{
							cout<<"\nNo Patients"<<endl;
							system("PAUSE");
						}
						else
						{
						
							while(read.get(c))
							cout<<c;
							read.close();
							cout<<"\n\n";
							system("PAUSE");
						}
					}
					
				}	break;
		case '2':
				{
					if(cardio=="N/A")
					{
						printf("\033c");
						cout<<"Theres no Cardiologist registered in the system please contact the system administrator";
						goto D;	
					}
					else
					{
						read.open("doctor/cardiologist/patients");
						if(read==NULL)
						{
							cout<<"\nNo Patients"<<endl;
							system("PAUSE");
						}
						else
						{
						
							while(read.get(c))
							cout<<c;
							read.close();
							cout<<"\n\n";
							system("PAUSE");
						}
					}
					
				}	break;
		case '3':
				{
					if(neuro=="N/A")
					{
						printf("\033c");
						cout<<"Theres no Neurologist registered in the system please contact the system administrator";
						goto D;		
					}
					else
					{
						read.open("doctor/neurologist/patients");
						if(read==NULL)
						{
							cout<<"\nNo Patients"<<endl;
							system("PAUSE");
						}
						else
						{
						
							while(read.get(c))
							cout<<c;
							read.close();
							cout<<"\n\n";
							system("PAUSE");
						}
					}
					
				}	break;
		case '4':
				{
					if(dermato=="N/A")
					{
						printf("\033c");
						cout<<"Theres no Dermatologist registered in the system please contact the system administrator";
						goto D;		
					}
					else
					{
						read.open("doctor/dermatologist/patients");
						if(read==NULL)
						{
							cout<<"\nNo Patients"<<endl;
							system("PAUSE");
						}
						else
						{
						
							while(read.get(c))
							cout<<c;
							read.close();
							cout<<"\n\n";
							system("PAUSE");
						}
					}
					
				}	break;
				
		case '5':	receptionistmenu();	break;
		
		default: cout<<"\n\nInvalid Choice";
	}
	
}

void receptionist::bookadates()
{
	int dd,mm,yyyy;
	patient p;
	ofstream file;
	file.open("patient/pending/pendinglist",ios::app);
	
	p.getbkdata();
	
	printf("\033c");
	printf("\n\n  Enter the Date you want to book the Doctor:\n\n ");
      printf("\nEnter Year -");
      scanf("%d",&yyyy);
      	while(yyyy<2017 || yyyy>3000)
      		{
      			printf("\nYear is invalid please re enter : ");
      			scanf("%d",&yyyy);
			}
      
      printf("\nEnter Month -");
      scanf("%d",&mm);
      	while(mm<1 || mm>12)
      		{
      			printf("\nMonth is invalid please re enter : ");
      			scanf("%d",&mm);
			}
      printf("\nEnter Date -");
      scanf("%d",&dd);
      	while(1)
      		{
      			if((dd>=1 && dd<=31) && (mm==1 || mm==3 || mm==5 || mm==7 || mm==8 || mm==10 || mm==12))

		   	        {
		   	           printf("\n\n  Date is valid."); break;
		   	           
		   	        }
		   	     
		   	        else if((dd>=1 && dd<=30) && (mm==4 || mm==6 || mm==9 || mm==11))
		   	        {
				       printf("\n\n  Date is valid."); break;
				    }
				 
			        else if((dd>=1 && dd<=28) && (mm==2))
					{	
			           printf("\n\n  Date is valid."); break;
			        }
				 
			        else if((dd==29 && mm==2 && (yyyy%400==0 || yyyy%4==0 && yyyy%100!=0)))
			        {
			           printf("\n\n  Date is valid."); break;
			        }
				 
			        else
			        {
			           printf("\n\n  Day is invalid. : ");
					   scanf("%d",&dd);	
				    }
			}
	file<<"\nName = "<<p.name<<"\tDate = "<<yyyy<<"."<<mm<<"."<<dd<<"\tSEX = "<<p.sex<<"\tAge = "<<p.age<<"\tAddress = "<<p.address<<"\tBloodgroup = "<<p.bloodgroup;
	file.close();
}

void receptionist::viewbookeddates()
{
	ifstream read;
	char c;
	
	read.open("patient/pending/pendinglist");
	if(read==NULL)
	{
		cout<<"\nNo Pending Patients"<<endl;
		system("PAUSE");
	}
	else
	{
	
		while(read.get(c))
		cout<<c;
		read.close();
		cout<<"\n\n";
		system("PAUSE");
	}
}

class room
{
	protected:
		float charge;
		string rno;
		string descrip;
	public:
		~room(){}
};

class wardroom:room
{
	public:
		~wardroom(){}
		void bookroom();
		void clearroom();
		void viewroom();
};

void wardroom::bookroom()
{

	char ch;
	ifstream file;
	ofstream filew;
	patient p;
	D:
	printf("\033c");
	cout<<"========== ROOM BOOK MENU ==========";
	cout<<"\n\n1.Room 1";
	cout<<"\n2.Room 2";
	cout<<"\n3.Room 3";
	cout<<"\n4.Room 4";
	cout<<"\n5.Room 5";
	
	cout<<"\n\nEnter your choice : ";
	//cin.ignore();
	//cin>>ch;
	ch = getch();
	
		switch(ch)
		{
			case '1':
				{
					file.open("ward/room/room1/info");
					cout<<"\n\nRoom Info :";
					cout<<"\nType : A/C\nBeds : 1 Electric + 1 Normal\nFacilities : T.V / Attach Bathroom";
					if(file!=NULL)
					{
						cout<<"\n\nThe Room 1 is already booked please select a different room or clear the room \n\n";
						system("pause");

					}
					else
					{
						p.getdata();
						filew.open("ward/room/room1/info");
						filew<<p.p_id<<"\t"<<p.name;
						filew.close();
					}
					file.close();

				}	break;
			
			case '2':
				{
					file.open("ward/room/room2/info");
					cout<<"\n\nRoom Info :";
					cout<<"\nType : A/C\nBeds : 1 Electric\nFacilities : T.V / Attach Bathroom";
					if(file!=NULL)
					{
						cout<<"\n\nThe Room 2 is already booked please select a different room or clear the room \n\n";
						system("pause");

					}
					else
					{
						p.getdata();
						filew.open("ward/room/room2/info");
						filew<<p.p_id<<"\t"<<p.name;
						filew.close();
					}
					file.close();

				}	break;
			
			case '3':
				{
					file.open("ward/room/room3/info");
					cout<<"\n\nRoom Info :";
					cout<<"\nType : A/C\nBeds : 1 Normal\nFacilities : T.V";
					if(file!=NULL)
					{
						cout<<"\n\nThe Room 3 is already booked please select a different room or clear the room \n\n";
						system("pause");

					}
					else
					{
						p.getdata();
						filew.open("ward/room/room3/info");
						filew<<p.p_id<<"\t"<<p.name;
						filew.close();
					}
					file.close();

				}	break;
			
			case '4':
				{
					file.open("ward/room/room4/info");
					cout<<"\n\nRoom Info :";
					cout<<"\nType : Non A/C\nBeds : Normal\nFacilities : T.V / Attach Bathroom";
					if(file!=NULL)
					{
						cout<<"\n\nThe Room 4 is already booked please select a different room or clear the room \n\n";
						system("pause");

					}
					else
					{
						p.getdata();
						filew.open("ward/room/room4/info");
						filew<<p.p_id<<"\t"<<p.name;
						filew.close();
					}
					file.close();

				}	break;
			
			case '5':
				{
					file.open("ward/room/room5/info");
					cout<<"\n\nRoom Info :";
					cout<<"\nType : Non A/C\nBeds : 1 Normal\nFacilities : N/A";
					if(file!=NULL)
					{
						cout<<"\n\nThe Room 5 is already booked please select a different room or clear the room \n\n";
						system("pause");

					}
					else
					{
						p.getdata();
						filew.open("ward/room/room5/info");
						filew<<p.p_id<<"\t"<<p.name;
						filew.close();
					}
					file.close();

				}	break;
			
			default:
				cout<<"\n\nInvalid Choice";
				system("pause");
				goto D;
		}
	
}

void wardroom::clearroom()
{
	char ch;
	ofstream file;
	D:
	printf("\033c");
	cout<<"========== ROOM MENU ==========";
	cout<<"\n\n1.Room 1";
	cout<<"\n2.Room 2";
	cout<<"\n3.Room 3";
	cout<<"\n4.Room 4";
	cout<<"\n5.Room 5";
	
	cout<<"\n\nEnter your choice : ";
	//cin.ignore();
	//cin>>ch;
	ch = getch();
	
		switch(ch)
		{
			case '1':
				{
					file.open("ward/room/room1/info");
					file.close();
					remove("ward/room/room1/info");
					cout<<"\n\nRoom 1 Cleared successfully.....\n\n";
					system("pause");
				}	break;
			
			case '2':
				{
					file.open("ward/room/room2/info");
					file.close();
					remove("ward/room/room2/info");
					cout<<"\n\nRoom 2 Cleared successfully.....\n\n";
					system("pause");
				}	break;
			
			case '3':
				{
					file.open("ward/room/room3/info");
					file.close();
					remove("ward/room/room3/info");
					cout<<"\n\nRoom 3 Cleared successfully.....\n\n";
					system("pause");	
				}	break;
			
			case '4':
				{
					file.open("ward/room/room4/info");
					file.close();
					remove("ward/room/room4/info");
					cout<<"\n\nRoom 4 Cleared successfully.....\n\n";
					system("pause");
				}	break;
			
			case '5':
				{
					file.open("ward/room/room5/info");
					file.close();
					remove("ward/room/room5/info");
					cout<<"\n\nRoom 5 Cleared successfully.....\n\n";
					system("pause");
				}	break;
			
			
			default: 
				cout<<"\n\nInvalid Choice";
				system("pause");
				goto D;
		}
}

void wardroom::viewroom()
{
	
	char ch;
	ifstream file;
	string status;
	string pid;
	string pname;
	D:
	printf("\033c");
	cout<<"========== ROOM INFO MENU ==========";
	cout<<"\n\n1.Room 1";
	cout<<"\n2.Room 2";
	cout<<"\n3.Room 3";
	cout<<"\n4.Room 4";
	cout<<"\n5.Room 5";
	
	cout<<"\n\nEnter your choice : ";
	//cin.ignore();
	//cin>>ch;
	ch = getch();
	
		switch(ch)
		{
			case '1':
				{
					file.open("ward/room/room1/info");
					cout<<"\n\nRoom Info :";
					cout<<"\nType : A/C\nBeds : 1 Electric + 1 Normal\nFacilities : T.V / Attach Bathroom\nCHARGE PER DAY = Rs.8000";
					if(file==NULL)
					{
						status = "Available";
						pid = "N/A";
						pname = "N/A";
					}
					else
					{
						status = "N/A";
						file>>pid;
						file>>pname;
					}
					file.close();
					cout<<"\n\nStatus : "<<status;
					cout<<"\nPID : "<<pid;
					cout<<"\nPatient Name : "<<pname;
					cout<<"\n\n";
					system("pause");

				}	break;
			
			case '2':
				{
					file.open("ward/room/room2/info");
					cout<<"\n\nRoom Info :";
					cout<<"\nType : A/C\nBeds : 1 Electric\nFacilities : T.V / Attach Bathroom\nCHARGE PER DAY = Rs.6000";
					if(file==NULL)
					{
						status = "Available";
						pid = "N/A";
						pname = "N/A";
					}
					else
					{
						status = "N/A";
						file>>pid;
						file>>pname;
					}
					file.close();
					cout<<"\n\nStatus : "<<status;
					cout<<"\nPID : "<<pid;
					cout<<"\nPatient Name : "<<pname;
					cout<<"\n\n";
					system("pause");

				}	break;
			
			case '3':
				{
					file.open("ward/room/room3/info");
					cout<<"\n\nRoom Info :";
					cout<<"\nType : A/C\nBeds : 1 Normal\nFacilities : T.V\nCHARGE PER DAY = Rs.5000";
					if(file==NULL)
					{
						status = "Available";
						pid = "N/A";
						pname = "N/A";
					}
					else
					{
						status = "N/A";
						file>>pid;
						file>>pname;
					}
					file.close();
					cout<<"\n\nStatus : "<<status;
					cout<<"\nPID : "<<pid;
					cout<<"\nPatient Name : "<<pname;
					cout<<"\n\n";
					system("pause");

				}	break;
			
			case '4':
				{
					file.open("ward/room/room4/info");
					cout<<"\n\nRoom Info :";
					cout<<"\nType : Non A/C\nBeds : Normal\nFacilities : T.V / Attach Bathroom\nCHARGE PER DAY = Rs.4000";
					if(file==NULL)
					{
						status = "Available";
						pid = "N/A";
						pname = "N/A";
					}
					else
					{
						status = "N/A";
						file>>pid;
						file>>pname;
					}
					file.close();
					cout<<"\n\nStatus : "<<status;
					cout<<"\nPID : "<<pid;
					cout<<"\nPatient Name : "<<pname;
					cout<<"\n\n";
					system("pause");

				}	break;
			
			case '5':
				{
					file.open("ward/room/room5/info");
					cout<<"\n\nRoom Info :";
					cout<<"\nType : Non A/C\nBeds : 1 Normal\nFacilities : N/A\nCHARGE PER DAY = Rs.3000";
					if(file==NULL)
					{
						status = "Available";
						pid = "N/A";
						pname = "N/A";
					}
					else
					{
						status = "N/A";
						file>>pid;
						file>>pname;
					}
					file.close();
					cout<<"\n\nStatus : "<<status;
					cout<<"\nPID : "<<pid;
					cout<<"\nPatient Name : "<<pname;
					cout<<"\n\n";
					system("pause");

				}	break;
				
			
			default:
				cout<<"\n\nInvalid Choice";
				system("pause");
				goto D;
		}
	
}

class warden
{
	string uname;
	char password[15];
	string un;
	string pw;

	public:
		~warden(){}
		bool wardlogin();
		void wardmenu();
		void createreport();
		void viewroominfo();
		void registerpatient();
		void clearrooms();
};

bool warden::wardlogin()
{
	char c=' ';
	int n=1,i=0,a,b;
	string un,pw;
	ofstream flog;

	cout<<"\nEnter USER ID and PASSWORD below (You have only three chances to enter)";
	system("PAUSE");

	while(n<=3)
	{
		printf("\033c");
  		cout<<"\nUSER ID: ";
  		cin>>uname;
  		cout<<"\nPASSWORD: ";
  		while (i<=10)
		  {
		    password[i]=getch();
		    c=password[i];
		    if(c==13) break;
		    else printf("*");
		    i++;
		  }

	      password[i]='\0';
	      i=0;
	      printf("\033c");

	    //string su =string(uname);
	    string sp =string(password);

	    ifstream file("warden/ward");
	    if(file==NULL)
	    {
	    	cout<<"Theres no Signup details of Ward in Charge Please Contact Administrator for Registration"<<endl;
	    	system("PAUSE");
	    	loginmenu();
		}
		getline(file,un);
		getline(file,pw);
		file.close();

	    //a=uname.compare();
  		//b=sp.compare();

  		if(uname==un && sp==pw)
  		{
  			flog.open("logs/userlog",ios::app);
  			flog<<"\nLogin ID : Ward in Charge\t\tTime : "<<__TIMESTAMP__;
  			flog.close();
  			return true;
		}
		else
		{

			cout<<"\nWrong PASSWORD and/or USER ID. Now you have "<<3-n<<" more chance/s.";
	        sleep(2);
	        printf("\033c");
		}
	    n++;
	}

	if(n==4)
   	{
   		printf("\nYou can't log in.");
		delay();
	}
}

void warden::wardmenu()
{
	D:
	printf("\033c");
	char ch;
	cout<<"========== Ward in Charge Menu ==========";
	cout<<"\n\n1.View Room Info";
	cout<<"\n2.Register Patients";
	cout<<"\n3.Create Ward Report";
	cout<<"\n4.Clear Booked Rooms";
	cout<<"\n5.Login Menu";
	cout<<"\n6.Exit";
	
	cout<<"\n\nEnter Choice : ";
	//cin.ignore();
	//cin>>ch;
	ch = getch();
	
		switch(ch)
		{
			case '1':
			{
				viewroominfo();
				goto D;
			}	break;
			
			case '2':
			{
				registerpatient();
				goto D;
			}	break;
			
			case '3':
			{
				createreport();
				goto D;
			}	break;
			
			case '4':
			{
				clearrooms();
				goto D;
			}	break;
			
			case '5': loginmenu();	break;
			
			case '6': exit(2);	break;
			
			default: 
				cout<<"\n\nInvalid choice";
				goto D;	
		}
}

void warden::createreport()
{
	wardreport w;
	w.createreport();
}

void warden::viewroominfo()
{
	wardroom r;
	r.viewroom();
	wardmenu();
}

void warden::registerpatient()
{
	wardroom r;
	r.bookroom();
	wardmenu();	
}

void warden::clearrooms()
{
	wardroom r;
	r.clearroom();
	wardmenu();
}

class medicine
{
	string name;
	float uprice;
	int qty;
	float medamount;
	
	public:
		~medicine(){}
		string checkstatus(string);
		void updatemed(string,int);
		friend medicalbill;
		friend wardbill;
		friend pharmacist;
};

string medicine::checkstatus(string name)
{
	ifstream file;
	char path[100] = "pharmacy/meds/";
	strcat(path,name.c_str());
	file.open(path);
	
	if(file!=NULL)
	{
		file>>uprice;
		file>>qty;
		file.close();
		return "yes";
	}
	else
	{
		file.close();
		return "no";
	}
		
}

void medicine::updatemed(string name,int qun)
{
	ifstream rfile;
	ofstream wfile;
	char path[100] = "pharmacy/meds/";
	strcat(path,name.c_str());
	
	rfile.open(path);
	rfile>>uprice;
	rfile>>qty;
	rfile.close();
	
	qty=qty-qun;
	
	wfile.open(path);
	wfile<<uprice<<endl;
	wfile<<qty;
	wfile.close();
}

class test
{
	string name;
	float price;
	float testamount;
	
	public:
		~test(){}
		friend medicalbill;
		friend wardbill;
};

class bill
{
	protected:
		int billno;
		float totamount;
	public:
		~bill(){}
		virtual void calbill()	{}
};

class wardbill:bill
{
	float roomcharge;
	float days;
	float total;
	
	public:
		~wardbill(){}
		void calbill();
};

void wardbill::calbill()
{
	test t;
	medicine m;
	string name;
	int qty;
	ifstream rbill;
	ofstream wbill;
	ofstream bill;
	ifstream rsummary;
	ofstream wsummary;
	ofstream master;
	
	string mch="y";
	string tch="y";
	string no;
	int roomno=10;
	totamount =0;
	char path[100]="bills/ward/";
	
	
	rbill.open("bills/bno");
	rbill>>billno;
	++billno;
	rbill.close();
	
	ostringstream convert;
	convert<<billno;
	no = convert.str();
	
	cout<<"\n\nBill No. : "<<billno;
	
	strcat(path,no.c_str());

	bill.open(path);
	bill<<"Bill No. : "<<billno;
	
	bill<<"\nMedicine Info : \n";
	while(mch=="y"||mch=="Y")
	{
		cout<<"\n\nEnter Medicine Name : ";
		cin>>name;
		if(m.checkstatus(name)=="yes")
		{
			cout<<"\nEnter Unit Quantity : ";
			cin>>qty;
			
				if(qty>m.qty)
				{
					cout<<"\nCannot provide the quantity maximum quantity available is = "<<m.qty<<endl;
					system("pause");
					m.qty = 0;
				}
				else
				{
					m.qty=qty;
					m.updatemed(name,qty);
				}
		}
		else
		{
			cout<<"Medicine not found ";
			m.qty = 0;
			m.uprice =0;
			system("pause");
		}
		m.name = name;
		m.medamount=qty*m.uprice;
		totamount= totamount + m.medamount;
		
		bill<<"Name : "<<m.name<<"  -  "<<"Amount = Rs."<<m.medamount<<endl;
		
		cout<<"\n\nTo Enter another medicine press y or n to cancel : ";
		cin>>mch;
	}
	
	bill<<"\nTest Info : \n";
	while(tch=="y"||tch=="Y")
	{
		cout<<"\n\nEnter Test Name : ";
		cin>>t.name;
		cout<<"\nEnter Price : ";
		cin>>t.price;
		t.testamount=t.price;
		totamount= totamount + t.testamount;
		
		bill<<"Name : "<<t.name<<"  -  "<<"Amount = Rs."<<t.testamount<<endl;
		
		cout<<"\n\nTo Enter another test press y or n to cancel : ";
		cin>>tch;
	}
	
	while(roomno<1 || roomno >5)
	{
		cout<<"\n\nEnter Room No . (1,2,3,4,5) : ";
		cin>>roomno;
	}
	if(roomno==1)
		roomcharge=8000;
		
	else if(roomno==2)
		roomcharge=6000;
		
	else if(roomno==3)
		roomcharge=5000;
	
	else if(roomno==4)
		roomcharge=4000;
		
	else if(roomno==5)
		roomcharge=3000;
	
	cout<<"\nEnter no. of days : ";
	cin>>days;
	total = roomcharge*days;
	totamount = totamount + total;
	
	bill<<"\nRoom Charges : "<<total;
	
	cout<<"\n\nTotal Amount = Rs."<<totamount<<endl<<endl;
	system("pause");
	bill<<"\n\nTOTAL AMOUNT = "<<totamount;
	bill.close();	
	
	master.open("bills/master",ios::app);
	master<<billno<<"\t"<<totamount<<endl;
	master.close();
	
	wbill.open("bills/bno");
	wbill<<billno;
	wbill.close();
	
	float count,amount;
	rsummary.open("bills/wardsum");
	rsummary>>count;
	rsummary>>amount;
	rsummary.close();
	
	count++;
	amount=amount+totamount;
	
	wsummary.open("bills/wardsum");
	wsummary<<count<<"\t"<<amount;
	wsummary.close();
}

class medicalbill:bill
{		
	public:
		~medicalbill(){}
		void calbill();
};

void medicalbill::calbill()
{
	test t;
	string name;
	int qty;
	medicine m;
	ifstream rbill;
	ofstream wbill;
	ofstream bill;
	ifstream rsummary;
	ofstream wsummary;
	ofstream master;
	
	string mch="y";
	string tch="y";
	string no;
	totamount =0;
	char path[100]="bills/medical/";
	
	rbill.open("bills/bno");
	rbill>>billno;
	++billno;
	rbill.close();
	
	ostringstream convert;
	convert<<billno;
	no = convert.str();
	
	cout<<"\n\nBill No. : "<<billno;
	
	strcat(path,no.c_str());

	bill.open(path);
	bill<<"Bill No. : "<<billno;
	
	bill<<"\nMedicine Info : \n";
	while(mch=="y"||mch=="Y")
	{
		cout<<"\n\nEnter Medicine Name : ";
		cin>>name;
		if(m.checkstatus(name)=="yes")
		{
			cout<<"\nEnter Unit Quantity : ";
			cin>>qty;
			
				if(qty>m.qty)
				{
					cout<<"\nCannot provide the quantity maximum quantity available is = "<<m.qty<<endl;
					system("pause");
					m.qty = 0;
				}
				else
				{
					m.qty=qty;
					m.updatemed(name,qty);
				}
		}
		else
		{
			cout<<"Medicine not found ";
			m.qty = 0;
			m.uprice =0;
			system("pause");
		}
		/*
		cout<<"\nEnter Unit Price : ";
		cin>>m.uprice;
		*/
		m.name = name;
		m.medamount=qty*m.uprice;
		totamount= totamount + m.medamount;
		
		bill<<"Name : "<<m.name<<"  -  "<<"Amount = Rs."<<m.medamount<<endl;
		
		cout<<"\n\nTo Enter another medicine press y or n to cancel : ";
		cin>>mch;
	}
	
	bill<<"\nTest Info : \n";
	while(tch=="y"||tch=="Y")
	{
		cout<<"\n\nEnter Test Name : ";
		cin>>t.name;
		cout<<"\nEnter Price : ";
		cin>>t.price;
		t.testamount=t.price;
		totamount= totamount + t.testamount;
		
		bill<<"Name : "<<t.name<<"  -  "<<"Amount = Rs."<<t.testamount<<endl;
		
		cout<<"\n\nTo Enter another test press y or n to cancel : ";
		cin>>tch;
	}
	totamount=totamount+1000;
	cout<<"\n\nTotal Amount = Rs."<<totamount<<endl<<endl;
	system("pause");
	bill<<"\nChanelling Charges = 1000";
	bill<<"\n\nTOTAL AMOUNT = "<<totamount;
	bill.close();	
	
	master.open("bills/master",ios::app);
	master<<billno<<"\t"<<totamount<<endl;
	master.close();
		
	wbill.open("bills/bno");
	wbill<<billno;
	wbill.close();
	
	float count,amount;
	rsummary.open("bills/medsum");
	rsummary>>count;
	rsummary>>amount;
	rsummary.close();
	
	count++;
	amount=amount+totamount;
	
	wsummary.open("bills/medsum");
	wsummary<<count<<"\t"<<amount;
	wsummary.close();
	
	
}

class cashier
{
	string uname;
	char password[15];
	string un;
	string pw;

	public:
		bool cashierlogin();
		void cashiermenu();
		void generatebill();
		void viewbill();
};

bool cashier::cashierlogin()
{
	char c=' ';
	int n=1,i=0,a,b;
	string un,pw;
	ofstream flog;

	cout<<"\nEnter USER ID and PASSWORD below (You have only three chances to enter)";
	system("PAUSE");

	while(n<=3)
	{
		printf("\033c");
  		cout<<"\nUSER ID: ";
  		cin>>uname;
  		cout<<"\nPASSWORD: ";
  		while (i<=10)
		  {
		    password[i]=getch();
		    c=password[i];
		    if(c==13) break;
		    else printf("*");
		    i++;
		  }

	      password[i]='\0';
	      i=0;
	      printf("\033c");

	    //string su =string(uname);
	    string sp =string(password);

	    ifstream file("cashier/cash");
	    if(file==NULL)
	    {
	    	cout<<"Theres no Signup details of Cashier Please Contact Administrator for Registration"<<endl;
	    	system("PAUSE");
	    	loginmenu();
		}
		getline(file,un);
		getline(file,pw);
		file.close();

	    //a=uname.compare();
  		//b=sp.compare();

  		if(uname==un && sp==pw)
  		{
  			flog.open("logs/userlog",ios::app);
  			flog<<"\nLogin ID : Cashier\t\tTime : "<<__TIMESTAMP__;
  			flog.close();
  			return true;
		}
		else
		{

			cout<<"\nWrong PASSWORD and/or USER ID. Now you have "<<3-n<<" more chance/s.";
	        sleep(2);
	        printf("\033c");
		}
	    n++;
	}

	if(n==4)
   	{
   		printf("\nYou can't log in.");
		delay();
	}
}

void cashier::cashiermenu()
{
	char ch;
	D:
	while(1)
	{
		
		printf("\033c");
		cout<<"========== Cashier Menu ==========";
		cout<<"\n\n1.Generate Bill";
		cout<<"\n2.View Bills";
		cout<<"\n3.Login Menu";
		cout<<"\n4.Exit";
		
		cout<<"\n\nEnter Choice : ";
		//cin.ignore();
		//cin>>ch;
		ch = getch();
			
			switch(ch)
			{
				case '1':	generatebill();	break;
				case '2':	viewbill();	break;
				case '3':	loginmenu();	break;
				case '4':	exit(2);	break;
				default:  
					cout<<"\n\nInvalid Choice\n\n";
					system("pause");
					goto D;
			}
	}
}

void cashier::generatebill()
{
	int ch,c=0;
	string sid,no,id,meds,scan,rno;
	D:
	ifstream file;
	
	printf("\033c");
	cout<<"1.Generate Medical Bill";
	cout<<"\n2.Generate Ward Bill";
	cout<<"\n3.Back";
	cout<<"\n\nEnter Choice : ";
	//cin.clear();
	cin>>ch;
	
	if(ch==1)
	{
		file.open("report/medical/report");
		cout<<"\n\nEnter the Patient ID that you want to generate the bill : ";
		cin>>sid;
		
		while(file>>no)
		{
			file>>id;
			file>>meds;
			file>>scan;
			
			if(id==sid)
			{
				cout<<"\n\nPatient number found press any key to calculate bill\n";
				system("pause");
				file.close();
				c++;
				break;
			}
		}
		
		if(c==0)
		{
			cout<<"\n\nTheres no patient id "<<sid<<" available to generate report please contact the assigned doctor\n\n";
			system("pause");
			file.close();
			goto D;
		}
		printf("\033c");
		cout<<"\nReport NO : "<<no;
		cout<<"\nPatient ID : "<<id;
		cout<<"\nMedicine : "<<meds;
		cout<<"\nScans : "<<scan;
		medicalbill m;
		m.calbill();
		cashier c;
		c.cashiermenu();
	}
	else if(ch==2)
	{
		file.open("report/ward/report");
		cout<<"\n\nEnter the Patient ID that you want to generate the bill : ";
		cin>>sid;
		
		while(file>>no)
		{
			file>>id;
			file>>rno;
			file>>meds;
			file>>scan;
			
			if(id==sid)
			{
				cout<<"\n\nPatient number found press any key to calculate bill\n";
				system("pause");
				file.close();
				c++;
				break;
			}
		}
		
		if(c==0)
		{
			cout<<"\n\nTheres no patient id "<<sid<<" available to generate report please contact the assigned doctor\n\n";
			system("pause");
			file.close();
			goto D;
		}
		printf("\033c");
		cout<<"\nReport NO : "<<no;
		cout<<"\nPatient ID : "<<id;
		cout<<"\nRoom NO : "<<rno;
		cout<<"\nMedicine : "<<meds;
		cout<<"\nScans : "<<scan;
		wardbill w;
		w.calbill();
		cashier c;
		c.cashiermenu();
	}
	else if(ch==3)
	{
		cashier c;
		c.cashiermenu();
	}
	else
	{
		cout<<"\n\nInvalid Choice\n\n";
		system("pause");
		goto D;
	}
}

void cashier::viewbill()
{
	int ch;
	D:
	printf("\033c");
	cout<<"1.View Medical Bill";
	cout<<"\n2.View Ward Bill";
	cout<<"\n3.Back";
	cout<<"\n\nEnter Choice : ";
	//cin.clear();
	cin>>ch;

	
	if(ch==1)
	{
		char path[100]="bills/medical/";
		string no;
		cout<<"\n\nEnter Medical bill no. : ";
		cin>>no;
		strcat(path,no.c_str());
		ifstream file;
		file.open(path);
		if(file==NULL)
		{
			cout<<"\n\nThere is no bill named "<<no;
			cout<<"\n\n";
			system("pause");
			goto D;
		}
		else
		{
			char c;
			while(file.get(c))
			cout<<c;
			cout<<"\n\n";
			system("pause");
		}
		file.close();
		cashier c;
		c.cashiermenu();
	}
	else if(ch==2)
	{
		char path[100]="bills/ward/";
		string no;
		cout<<"\n\nEnter Ward bill no. : ";
		cin>>no;
		
		strcat(path,no.c_str());
		ifstream file;
		file.open(path);
		if(file==NULL)
		{
			cout<<"\n\nThere is no bill named "<<no;
			cout<<"\n\n";
			system("pause");
			goto D;
		}
		else
		{
			char c;
			while(file.get(c))
			cout<<c;
			cout<<"\n\n";
			system("pause");
		}
		file.close();
		cashier c;
		c.cashiermenu();
	}
	else if(ch==3)
	{
		cashier c;
		c.cashiermenu();
	}
	else
	{
		cout<<"\n\nInvalid Choice\n\n";
		system("pause");
		goto D;
	}
}

class pharmacist
{
	string username;
	string password;
	void pharmacymenu();
	void addmeds();
	void searchmeds();
	void updatemeds();
	void delmeds();
	
	public:
		~pharmacist(){}
		pharmacist()
		{
			ifstream p;
			p.open("pharmacist/phar");
			p>>username;
			p>>password;
			p.close();
		}
	
		void pharlogin();	
};

void pharmacist::pharlogin()
{
	char p[15],u[15],c=' ';
	int n=1,i=0,a,b;
	
	cout<<"\nEnter USER ID and PASSWORD below (You have only three chances to enter)";
	system("PAUSE");
	D:
	while(n<=3)
	{
		printf("\033c");
  		cout<<"\nUSER ID: ";
  		cin>>u;
  		cout<<"\nPASSWORD: ";
  		while (i<=10)
		  {
		    p[i]=getch();
		    c=p[i];
		    if(c==13) break;
		    else printf("*");
		    i++;
		  }

	      p[i]='\0';
	      i=0;
	      printf("\033c");

	    string su =string(u);
	    string sp =string(p);

	    a=su.compare(username);
  		b=sp.compare(password);

  		if(a==0 && b==0)
  		{
  			printf("\033c");
  			pharmacymenu();
		}
		else
		{

			cout<<"\nWrong PASSWORD and/or USER ID. Now you have "<<3-n<<" more chance/s.";
	        sleep(2);
	        printf("\033c");
	        goto D;
		}
	    n++;
	}

	if(n==4)
   	{
   		printf("\nYou can't log in.");
   		sleep(2);
		delay();
		loginmenu();
	}
}

void pharmacist::pharmacymenu()
{
	char ch;
	D:
	printf("\033c");
	cout<<"========== Pharmacy Menu ==========";
	cout<<"\n\n1.Add Medicine";
	cout<<"\n2.Search Medicine";
	cout<<"\n3.Update Medicine";
	cout<<"\n4.Delete Medicine";
	cout<<"\n5.Login Menu";
	cout<<"\n6.Exit";
	
	cout<<"\n\nEnter your Choice : ";
	//cin.clear();
	//cin>>ch;
	ch = getch();
	
		switch(ch)
		{
			case '1':	
				addmeds();	
				goto D;	
					break;
			case '2':	
				searchmeds();	
				goto D;	
					break;
			case '3':	
				updatemeds();	
				goto D;	
					break;
			case '4':	
				delmeds();	
				goto D;	
					break;
			case '5':	
				loginmenu();	
				goto D;	
					break;
			case '6':	
				exit(2);	
					break;
			default:
				{
					cout<<"\n\nInvalid Choice"<<endl;
					system("Pause");
					goto D;
				}
		}
}

void pharmacist::addmeds()
{
	char path[100]="pharmacy/meds/";
	medicine m;
	ifstream rfile;
	ofstream wfile;
	
	printf("\033c");
	cout<<"\nEnter Medicine name you want to add (use lowercase letters only) - ";
	cin>>m.name;
	
	strcat(path,m.name.c_str());
	
	rfile.open(path);
	if(rfile!=NULL)
	{
		cout<<"\nThere is already a medicine called "<<m.name<<" please rechechk name or update it\n";
		system("pause");
		rfile.close();
		pharmacymenu();
	}
	else
	{
		rfile.close();
		wfile.open(path);
		cout<<"\nEnter Unit Price : ";
		cin>>m.uprice;
		cout<<"\nEnter Quantity : ";
		cin>>m.qty;
		wfile<<m.uprice<<endl;
		wfile<<m.qty;
		wfile.close();
		cout<<"\n\nMedicine added succesfully....\n\n";
		system("pause");
		pharmacymenu();
	}
}

void pharmacist::searchmeds()
{
	
	char path[100]="pharmacy/meds/";
	medicine m;
	ifstream rfile;
	ofstream wfile;
	
	printf("\033c");
	cout<<"\nEnter Medicine name you want to search (use lowercase letters only) - ";
	cin>>m.name;
	
	strcat(path,m.name.c_str());
	
	rfile.open(path);
	if(rfile==NULL)
	{
		cout<<"\nThere is no medicine called "<<m.name<<" please rechechk name\n";
		system("pause");
		pharmacymenu();
	}
	else
	{
		rfile>>m.uprice;
		rfile>>m.qty;
		rfile.close();
		cout<<"\n\nMedicine Name : "<<m.name;
		cout<<"\nUnit Price : "<<m.uprice;
		cout<<"\nQuantity Available : "<<m.qty<<endl;
		system("pause");
		pharmacymenu();
	}
	
}

void pharmacist::updatemeds()
{
	
	char path[100]="pharmacy/meds/";
	medicine m;
	int a,b;
	ifstream rfile;
	ofstream wfile;
	
	printf("\033c");
	cout<<"\nEnter Medicine name you want to update (use lowercase letters only) - ";
	cin>>m.name;
	
	strcat(path,m.name.c_str());
	
	rfile.open(path);
	if(rfile==NULL)
	{
		cout<<"\nThere is no medicine called "<<m.name<<" please rechechk name\n";
		system("pause");
		rfile.close();
		pharmacymenu();
	}
	else
	{
		rfile>>a;
		rfile>>b;
		rfile.close();
		wfile.open(path);
		cout<<"\nEnter Unit Price : ";
		cin>>m.uprice;
		cout<<"\nEnter Quantity : ";
		cin>>m.qty;
		m.qty=m.qty+b;
		wfile<<m.uprice<<endl;
		wfile<<m.qty;
		wfile.close();
		cout<<"\n\nMedicine updated succesfully....\n\n";
		system("pause");
		pharmacymenu();
	}
	
}

void pharmacist::delmeds()
{
	
	char path[100]="pharmacy/meds/";
	medicine m;
	ifstream rfile;
	ofstream wfile;
	
	printf("\033c");
	cout<<"\nEnter Medicine name you want to delete (use lowercase letters only) - ";
	cin>>m.name;
	
	strcat(path,m.name.c_str());
	
	rfile.open(path);
	if(rfile==NULL)
	{
		cout<<"\nThere is no medicine called "<<m.name<<" please rechechk name\n";
		system("pause");
		rfile.close();
		pharmacymenu();
	}
	else
	{
		rfile.close();
		remove(path);
		cout<<"\nMedicine Deleted Successfully\n\n";
		system("pause");
		pharmacymenu();
	}
	
}

//functions

void loginmenu()
{
	char ch;
	cout <<"\t\t\t\t\t\t\t\t\t\t"<<__TIMESTAMP__ << endl;

	while(1)
	{
		
	
		printf("\033c");
		system("Color F1");
		cout<<"\n\n========== LOGIN MENU ==========\t\t\t\t\t\t\t      ";
		cout<<"\n\n1.Admin";
		cout<<"\n2.Receptionist";
		cout<<"\n3.Doctor";
		cout<<"\n4.Ward In Charge";
		cout<<"\n5.Cashier";
		cout<<"\n6.Pharmacist";
		cout<<"\n7.About Program";
		cout<<"\n8.Exit from program";
	
		cout<<"\n\nplease Enter your choice to log in to System - ";
		//cin>>ch;
		ch = getch();
	
		switch(ch)
		{
			case '1':
				{
					admin adm;
					char p[15],u[15],c=' ';
					int n=1,i=0,a,b;
					string username = adm.getuname();
					string password = adm.getpwrd();
	
					cout<<"\nEnter USER ID and PASSWORD below (You have only three chances to enter)";
		   			system("PAUSE");
	
		   			while(n<=3)
		   			{
		   				printf("\033c");
			      		cout<<"\nUSER ID: ";
			      		cin>>u;
			      		cout<<"\nPASSWORD: ";
			      		while (i<=10)
						  {
						    p[i]=getch();
						    c=p[i];
						    if(c==13) break;
						    else printf("*");
						    i++;
						  }
	
					      p[i]='\0';
					      i=0;
					      printf("\033c");
	
					    string su =string(u);
					    string sp =string(p);
	
					    a=su.compare(username);
			      		b=sp.compare(password);
	
			      		if(a==0 && b==0)
			      		{
			      			printf("\033c");
			      			adm.adminmenu();
						}
						else
						{
	
							cout<<"\nWrong PASSWORD and/or USER ID. Now you have "<<3-n<<" more chance/s.";
					        sleep(2);
					        printf("\033c");
						}
					    n++;
					}
	
					if(n==4)
				   	{
				   		printf("\nYou can't log in.");
						delay();
					}
	
				} break;
	
			case '2':
				{
					receptionist r;
	
					if(r.receplogin())
					{
						r.receptionistmenu();
					}
	
				} break;
	
			case '3':
				{
					
					doctor doc;
					char p[15],u[15],c=' ';
					int n=1,i=0,a,b;
					string username = doc.getuname();
					string password = doc.getpwrd();
	
					cout<<"\nEnter USER ID and PASSWORD below (You have only three chances to enter)";
		   			system("PAUSE");
	
		   			while(n<=3)
		   			{
		   				printf("\033c");
			      		cout<<"\nUSER ID: ";
			      		cin>>u;
			      		cout<<"\nPASSWORD: ";
			      		while (i<=10)
						  {
						    p[i]=getch();
						    c=p[i];
						    if(c==13) break;
						    else printf("*");
						    i++;
						  }
	
					      p[i]='\0';
					      i=0;
					      printf("\033c");
	
					    string su =string(u);
					    string sp =string(p);
	
					    a=su.compare(username);
			      		b=sp.compare(password);
	
			      		if(a==0 && b==0)
			      		{
			      			printf("\033c");
			      			doclogselect();
			      			break;
						}
						else
						{
	
							cout<<"\nWrong PASSWORD and/or USER ID. Now you have "<<3-n<<" more chance/s.";
					        sleep(2);
					        printf("\033c");
						}
					    n++;
					}
	
					if(n==4)
				   	{
				   		printf("\nYou can't log in.");
						delay();
					}
	
				} break;
	
			case '4':
				{
					warden w;
					if(w.wardlogin())
					{
						w.wardmenu();
					}
				} break;
	
			case '5':
				{
					cashier c;
	
					if(c.cashierlogin())
					{
						c.cashiermenu();
					}
	
				} break;
			
			case '6':
				{
					pharmacist p;
					p.pharlogin();
				}	break;
	
			case '7':
				{
					about();
				} break;
	
			case '8': exit(0); break;
	
			default : 
				{
					cout<<"\n\n Invalid Choice"<<endl;
					system("pause");
					loginmenu();
				}
		}
	}
}

void about()
{
	printf("\033c");
	cout<<"\n\n\n\n\n\n";
	cout<<"\t= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = ";
	cout<<"\n\n";
	cout<<"\t\t\t\tHOSPITAL MANAGEMENT SYSTEMS WITH PHARMACY";
	cout<<"\n\t\t\t\t\t\tVersion 1.0";
	cout<<"\n\t= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = \n\n\t\t\t\t\t";
	system("pause");
}

void delay()
{
	for(int c=10;c>0;c--)
		{
			printf("\033c");
			cout<<"Please wait "<<c<<" Seconds before login";
			sleep(1);
		}
	loginmenu();
}

int main()
{
	loginmenu();
	return 0;
}

